const { config } = require("./app-config");

module.exports = {
  config,
};
