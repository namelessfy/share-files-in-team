const { connect } = require("./connect");

module.exports = {
  connect,
};
